import { Router } from "express";

import { authenticate } from "../../middleware/authenticate";
import { authorize } from "../../middleware/authorize";
import { validate } from "../../middleware/validate";

import {
  createAccount,
  updateAccountStatus,
} from "../controllers/account.controller";

import {
  getAccounts,
  getAccount,
} from "../controllers/account.controller";

import {
  createAccountSchema,
  updateAccountStatusSchema,
} from "../schemas/account.schema";

const router = Router();

router.post(
  "/",
  authenticate,
  authorize("CUSTOMER"),
  validate({
    body: createAccountSchema,
  }),
  createAccount,
);

router.get(
  "/",
  authenticate,
  authorize("CUSTOMER"),
  getAccounts,
);

router.get(
  "/:accountId",
  authenticate,
  authorize("CUSTOMER"),
  getAccount,
);

router.patch(
  "/:accountId/status",
  authenticate,
  authorize("CUSTOMER"),
  validate({
    body: updateAccountStatusSchema,
  }),
  updateAccountStatus,
);

export default router;